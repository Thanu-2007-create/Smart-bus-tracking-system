import { Router } from "express";
import db from "../db.js";
import { authenticate, authorize } from "../middleware/auth.js";

const router = Router();
router.use(authenticate);

// Start a trip (driver)
router.post("/trips/start", authorize("driver"), (req, res) => {
  const { bus_id, route_id, trip_type } = req.body;
  const info = db
    .prepare(
      `INSERT INTO trips (bus_id, route_id, driver_id, trip_type, status, start_time)
       VALUES (?,?,?,?, 'active', datetime('now'))`
    )
    .run(bus_id, route_id, req.user.id, trip_type);
  res.status(201).json({ id: info.lastInsertRowid });
});

// End a trip (driver)
router.post("/trips/:id/end", authorize("driver"), (req, res) => {
  db.prepare(
    "UPDATE trips SET status='completed', end_time=datetime('now') WHERE id=?"
  ).run(req.params.id);

  const summary = db
    .prepare(
      `SELECT
         (SELECT COUNT(*) FROM attendance WHERE trip_id=?) AS total_marked,
         (SELECT COUNT(*) FROM attendance WHERE trip_id=? AND status='late') AS late_count`
    )
    .get(req.params.id, req.params.id);
  res.json({ success: true, summary });
});

// Get active trips (for map / dashboards)
router.get("/trips/active", (req, res) => {
  const trips = db
    .prepare(
      `SELECT t.*, b.bus_number, r.name AS route_name
       FROM trips t
       JOIN buses b ON b.id = t.bus_id
       JOIN routes r ON r.id = t.route_id
       WHERE t.status='active'`
    )
    .all();
  res.json(trips);
});

// Get a driver's trips for today
router.get("/trips/mine", authorize("driver"), (req, res) => {
  const trips = db
    .prepare(
      `SELECT t.*, b.bus_number, r.name AS route_name
       FROM trips t JOIN buses b ON b.id=t.bus_id JOIN routes r ON r.id=t.route_id
       WHERE t.driver_id=? AND t.date=date('now') ORDER BY t.id DESC`
    )
    .all(req.user.id);
  res.json(trips);
});

export default router;
