import { Router } from "express";
import db from "../db.js";
import { authenticate } from "../middleware/auth.js";

const router = Router();
router.use(authenticate);

router.get("/alerts/mine", (req, res) => {
  const rows = db
    .prepare("SELECT * FROM alerts WHERE target_user_id=? ORDER BY created_at DESC LIMIT 50")
    .all(req.user.id);
  res.json(rows);
});

router.post("/alerts/:id/read", (req, res) => {
  db.prepare("UPDATE alerts SET is_read=1 WHERE id=? AND target_user_id=?").run(
    req.params.id,
    req.user.id
  );
  res.json({ success: true });
});

// Driver/Admin: raise an SOS with current location
router.post("/alerts/sos", (req, res) => {
  const { bus_id, message, latitude, longitude } = req.body;
  // notify all admins
  const admins = db.prepare("SELECT id FROM users WHERE role='admin'").all();
  const insert = db.prepare(
    "INSERT INTO alerts (type,target_user_id,bus_id,message) VALUES ('sos',?,?,?)"
  );
  const fullMsg = `${message || "SOS raised"} @ (${latitude}, ${longitude})`;
  admins.forEach((a) => insert.run(a.id, bus_id, fullMsg));

  // also notify parents of students on that bus's route
  const parents = db
    .prepare(
      `SELECT DISTINCT s.parent_id FROM students s
       JOIN routes r ON r.id = s.route_id
       WHERE r.bus_id = ? AND s.parent_id IS NOT NULL`
    )
    .all(bus_id);
  parents.forEach((p) => insert.run(p.parent_id, bus_id, fullMsg));

  req.app.get("io").emit("sos_alert", { bus_id, message: fullMsg, latitude, longitude });
  res.status(201).json({ success: true });
});

export default router;
