import { Router } from "express";
import db from "../db.js";
import { authenticate, authorize } from "../middleware/auth.js";

const router = Router();
router.use(authenticate);

const LATE_ENTRIES_WARNING_COUNT = Number(process.env.LATE_ENTRIES_WARNING_COUNT || 3);

// Mark attendance (driver scans QR/RFID or manual override)
router.post("/attendance/mark", authorize("driver"), (req, res) => {
  const { trip_id, student_id, stop_id, method, reason } = req.body;

  const stop = db.prepare("SELECT * FROM stops WHERE id=?").get(stop_id);
  const now = new Date();
  const nowHM = now.toTimeString().slice(0, 5); // "HH:MM"

  let status = "present";
  if (stop && stop.expected_time && nowHM > stop.expected_time) {
    status = "late";
  }

  const info = db
    .prepare(
      `INSERT INTO attendance (trip_id, student_id, stop_id, status, method, reason)
       VALUES (?,?,?,?,?,?)`
    )
    .run(trip_id, student_id, stop_id, status, method || "manual", reason || null);

  let warningTriggered = false;
  if (status === "late") {
    const monthLateCount = db
      .prepare(
        `SELECT COUNT(*) c FROM attendance
         WHERE student_id=? AND status='late' AND strftime('%Y-%m', timestamp)=strftime('%Y-%m','now')`
      )
      .get(student_id).c;

    if (monthLateCount >= LATE_ENTRIES_WARNING_COUNT) {
      warningTriggered = true;
      const student = db
        .prepare(
          `SELECT s.*, u.id AS user_id, u.name FROM students s JOIN users u ON u.id=s.user_id WHERE s.id=?`
        )
        .get(student_id);
      if (student) {
        db.prepare(
          `INSERT INTO alerts (type, target_user_id, message) VALUES ('late_warning', ?, ?)`
        ).run(
          student.user_id,
          `You have ${monthLateCount} late entries this month. Please be on time to avoid disciplinary action.`
        );
        if (student.parent_id) {
          db.prepare(
            `INSERT INTO alerts (type, target_user_id, message) VALUES ('late_warning', ?, ?)`
          ).run(
            student.parent_id,
            `Your child has ${monthLateCount} late entries this month.`
          );
        }
      }
    }
  }

  res.status(201).json({ id: info.lastInsertRowid, status, warningTriggered });
});

// Attendance for a specific student (self or parent's child)
router.get("/attendance/student/:studentId", (req, res) => {
  const rows = db
    .prepare(
      `SELECT a.*, s.name AS stop_name FROM attendance a
       LEFT JOIN stops s ON s.id = a.stop_id
       WHERE a.student_id=? ORDER BY a.timestamp DESC LIMIT 100`
    )
    .all(req.params.studentId);
  res.json(rows);
});

// Monthly summary for a student
router.get("/attendance/student/:studentId/summary", (req, res) => {
  const summary = db
    .prepare(
      `SELECT
         SUM(CASE WHEN status='present' THEN 1 ELSE 0 END) AS present_count,
         SUM(CASE WHEN status='late' THEN 1 ELSE 0 END) AS late_count,
         SUM(CASE WHEN status='absent' THEN 1 ELSE 0 END) AS absent_count
       FROM attendance
       WHERE student_id=? AND strftime('%Y-%m', timestamp)=strftime('%Y-%m','now')`
    )
    .get(req.params.studentId);
  res.json(summary);
});

// Admin: late entry report, filterable by route/date
router.get("/attendance/late-report", authorize("admin"), (req, res) => {
  const rows = db
    .prepare(
      `SELECT a.id, a.timestamp, a.status, u.name AS student_name, r.name AS route_name, st.name AS stop_name
       FROM attendance a
       JOIN students s ON s.id = a.student_id
       JOIN users u ON u.id = s.user_id
       LEFT JOIN routes r ON r.id = s.route_id
       LEFT JOIN stops st ON st.id = a.stop_id
       WHERE a.status='late'
       ORDER BY a.timestamp DESC LIMIT 500`
    )
    .all();
  res.json(rows);
});

export default router;
