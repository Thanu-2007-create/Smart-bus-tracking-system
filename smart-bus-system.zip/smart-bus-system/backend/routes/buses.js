import { Router } from "express";
import db from "../db.js";
import { authenticate, authorize } from "../middleware/auth.js";

const router = Router();
router.use(authenticate);

// ---- BUSES ----
router.get("/buses", (req, res) => {
  const buses = db
    .prepare(
      `SELECT b.*, u.name AS driver_name, u.phone AS driver_phone
       FROM buses b LEFT JOIN users u ON u.id = b.driver_id`
    )
    .all();
  res.json(buses);
});

router.post("/buses", authorize("admin"), (req, res) => {
  const { bus_number, capacity, driver_id, facilities } = req.body;
  const info = db
    .prepare("INSERT INTO buses (bus_number,capacity,driver_id,facilities) VALUES (?,?,?,?)")
    .run(bus_number, capacity, driver_id || null, facilities || "");
  res.status(201).json({ id: info.lastInsertRowid });
});

router.put("/buses/:id", authorize("admin"), (req, res) => {
  const { bus_number, capacity, driver_id, facilities } = req.body;
  db.prepare(
    "UPDATE buses SET bus_number=?, capacity=?, driver_id=?, facilities=? WHERE id=?"
  ).run(bus_number, capacity, driver_id || null, facilities || "", req.params.id);
  res.json({ success: true });
});

router.delete("/buses/:id", authorize("admin"), (req, res) => {
  db.prepare("DELETE FROM buses WHERE id=?").run(req.params.id);
  res.json({ success: true });
});

// ---- ROUTES ----
router.get("/routes", (req, res) => {
  const routes = db.prepare("SELECT * FROM routes").all();
  res.json(routes);
});

router.post("/routes", authorize("admin"), (req, res) => {
  const { name, bus_id } = req.body;
  const info = db.prepare("INSERT INTO routes (name,bus_id) VALUES (?,?)").run(name, bus_id);
  res.status(201).json({ id: info.lastInsertRowid });
});

// ---- STOPS ----
router.get("/routes/:routeId/stops", (req, res) => {
  const stops = db
    .prepare("SELECT * FROM stops WHERE route_id=? ORDER BY seq ASC")
    .all(req.params.routeId);
  res.json(stops);
});

router.post("/routes/:routeId/stops", authorize("admin"), (req, res) => {
  const { name, seq, latitude, longitude, expected_time } = req.body;
  const info = db
    .prepare(
      "INSERT INTO stops (route_id,name,seq,latitude,longitude,expected_time) VALUES (?,?,?,?,?,?)"
    )
    .run(req.params.routeId, name, seq, latitude, longitude, expected_time);
  res.status(201).json({ id: info.lastInsertRowid });
});

// ---- STUDENTS ----
router.get("/students", authorize("admin", "driver"), (req, res) => {
  const students = db
    .prepare(
      `SELECT s.id, u.name, u.email, s.roll_number, s.route_id, s.stop_id, r.name AS route_name, st.name AS stop_name
       FROM students s
       JOIN users u ON u.id = s.user_id
       LEFT JOIN routes r ON r.id = s.route_id
       LEFT JOIN stops st ON st.id = s.stop_id`
    )
    .all();
  res.json(students);
});

router.post("/students", authorize("admin"), (req, res) => {
  const { user_id, route_id, stop_id, parent_id, roll_number } = req.body;
  const info = db
    .prepare(
      "INSERT INTO students (user_id,route_id,stop_id,parent_id,roll_number) VALUES (?,?,?,?,?)"
    )
    .run(user_id, route_id, stop_id, parent_id || null, roll_number || null);
  res.status(201).json({ id: info.lastInsertRowid });
});

export default router;
