import "dotenv/config";
import express from "express";
import cors from "cors";
import { createServer } from "http";
import { Server } from "socket.io";

import "./db.js"; // initializes + seeds DB on import
import authRoutes from "./routes/auth.js";
import busRoutes from "./routes/buses.js";
import tripRoutes from "./routes/trips.js";
import attendanceRoutes from "./routes/attendance.js";
import alertRoutes from "./routes/alerts.js";
import { registerSocketHandlers } from "./socket/index.js";

const app = express();
app.use(cors());
app.use(express.json());

const httpServer = createServer(app);
const io = new Server(httpServer, { cors: { origin: "*" } });
app.set("io", io);

app.get("/api/health", (req, res) => res.json({ ok: true, time: new Date().toISOString() }));

app.use("/api/auth", authRoutes);
app.use("/api", busRoutes);
app.use("/api", tripRoutes);
app.use("/api", attendanceRoutes);
app.use("/api", alertRoutes);

registerSocketHandlers(io);

const PORT = process.env.PORT || 5000;
httpServer.listen(PORT, () => {
  console.log(`Smart Bus backend running on http://localhost:${PORT}`);
});
