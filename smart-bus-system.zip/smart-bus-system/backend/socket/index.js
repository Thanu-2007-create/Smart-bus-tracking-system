import jwt from "jsonwebtoken";
import db from "../db.js";

const ALERT_THRESHOLDS_MIN = (process.env.COME_FAST_ALERT_MINUTES || "5,2")
  .split(",")
  .map(Number);

// naive average bus speed assumption (km/h) used when computing ETA from distance
const ASSUMED_SPEED_KMH = 25;

function haversineKm(lat1, lon1, lat2, lon2) {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

// track which thresholds have already fired per (trip_id, stop_id) to avoid spam
const firedAlerts = new Set();

export function registerSocketHandlers(io) {
  io.use((socket, next) => {
    try {
      const token = socket.handshake.auth?.token;
      if (!token) return next(new Error("No token"));
      socket.user = jwt.verify(token, process.env.JWT_SECRET);
      next();
    } catch (e) {
      next(new Error("Invalid token"));
    }
  });

  io.on("connection", (socket) => {
    // Each client joins a room to receive relevant events
    socket.join(`user:${socket.user.id}`);

    // Driver app sends periodic location updates while trip is active
    socket.on("driver:location", ({ trip_id, bus_id, latitude, longitude, speed }) => {
      if (socket.user.role !== "driver") return;

      db.prepare(
        "INSERT INTO locations (bus_id, trip_id, latitude, longitude, speed) VALUES (?,?,?,?,?)"
      ).run(bus_id, trip_id, latitude, longitude, speed || null);

      // Broadcast raw location to everyone watching this bus (students, parents, admin)
      io.emit("bus:location", { bus_id, trip_id, latitude, longitude, speed, timestamp: Date.now() });

      // ---- Compute ETA to each upcoming stop & trigger "come fast" alerts ----
      const trip = db.prepare("SELECT * FROM trips WHERE id=?").get(trip_id);
      if (!trip) return;
      const stops = db
        .prepare("SELECT * FROM stops WHERE route_id=? ORDER BY seq ASC")
        .all(trip.route_id);

      stops.forEach((stop) => {
        if (stop.latitude == null || stop.longitude == null) return;
        const distanceKm = haversineKm(latitude, longitude, stop.latitude, stop.longitude);
        const etaMinutes = (distanceKm / ASSUMED_SPEED_KMH) * 60;

        ALERT_THRESHOLDS_MIN.forEach((threshold) => {
          const key = `${trip_id}:${stop.id}:${threshold}`;
          if (etaMinutes <= threshold && etaMinutes > threshold - 1 && !firedAlerts.has(key)) {
            firedAlerts.add(key);
            const students = db
              .prepare("SELECT s.*, u.id AS user_id FROM students s JOIN users u ON u.id=s.user_id WHERE s.stop_id=?")
              .all(stop.id);
            const message = `Bus is ~${threshold} min away from ${stop.name} — come fast!`;
            students.forEach((st) => {
              db.prepare(
                "INSERT INTO alerts (type,target_user_id,bus_id,message) VALUES ('come_fast',?,?,?)"
              ).run(st.user_id, bus_id, message);
              io.to(`user:${st.user_id}`).emit("come_fast_alert", { stop: stop.name, etaMinutes: threshold, message });
              if (st.parent_id) {
                io.to(`user:${st.parent_id}`).emit("come_fast_alert", { stop: stop.name, etaMinutes: threshold, message });
              }
            });
          }
        });
      });
    });

    // Clear fired-alert cache when a trip ends so tomorrow's trip works normally
    socket.on("driver:trip_ended", ({ trip_id }) => {
      [...firedAlerts].forEach((k) => {
        if (k.startsWith(`${trip_id}:`)) firedAlerts.delete(k);
      });
      io.emit("trip:ended", { trip_id });
    });

    socket.on("disconnect", () => {});
  });
}
