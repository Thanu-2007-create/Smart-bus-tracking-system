import Database from "better-sqlite3";
import bcrypt from "bcryptjs";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const db = new Database(path.join(__dirname, "smartbus.sqlite"));
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

// ---------- SCHEMA ----------
db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  password TEXT NOT NULL,
  role TEXT CHECK(role IN ('student','driver','parent','admin')) NOT NULL,
  phone TEXT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS buses (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  bus_number TEXT UNIQUE NOT NULL,
  capacity INTEGER,
  driver_id INTEGER REFERENCES users(id),
  facilities TEXT
);

CREATE TABLE IF NOT EXISTS routes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  bus_id INTEGER REFERENCES buses(id)
);

CREATE TABLE IF NOT EXISTS stops (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  route_id INTEGER REFERENCES routes(id),
  name TEXT NOT NULL,
  seq INTEGER NOT NULL,
  latitude REAL,
  longitude REAL,
  expected_time TEXT -- 'HH:MM' expected boarding time window start
);

CREATE TABLE IF NOT EXISTS students (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER UNIQUE REFERENCES users(id),
  route_id INTEGER REFERENCES routes(id),
  stop_id INTEGER REFERENCES stops(id),
  parent_id INTEGER REFERENCES users(id),
  roll_number TEXT
);

CREATE TABLE IF NOT EXISTS trips (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  bus_id INTEGER REFERENCES buses(id),
  route_id INTEGER REFERENCES routes(id),
  driver_id INTEGER REFERENCES users(id),
  trip_type TEXT CHECK(trip_type IN ('morning','evening')) NOT NULL,
  status TEXT CHECK(status IN ('not_started','active','completed')) DEFAULT 'not_started',
  start_time TEXT,
  end_time TEXT,
  date TEXT DEFAULT (date('now'))
);

CREATE TABLE IF NOT EXISTS attendance (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  trip_id INTEGER REFERENCES trips(id),
  student_id INTEGER REFERENCES students(id),
  stop_id INTEGER REFERENCES stops(id),
  status TEXT CHECK(status IN ('present','late','absent')) DEFAULT 'present',
  method TEXT DEFAULT 'manual', -- qr/rfid/geofence/manual
  reason TEXT,
  timestamp TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS locations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  bus_id INTEGER REFERENCES buses(id),
  trip_id INTEGER REFERENCES trips(id),
  latitude REAL,
  longitude REAL,
  speed REAL,
  timestamp TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS alerts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  type TEXT CHECK(type IN ('come_fast','late_warning','sos','delay','info')) NOT NULL,
  target_user_id INTEGER REFERENCES users(id),
  bus_id INTEGER REFERENCES buses(id),
  message TEXT,
  is_read INTEGER DEFAULT 0,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
`);

// ---------- SEED (only if empty) ----------
const userCount = db.prepare("SELECT COUNT(*) c FROM users").get().c;
if (userCount === 0) {
  const hash = (pw) => bcrypt.hashSync(pw, 8);
  const insertUser = db.prepare(
    "INSERT INTO users (name,email,password,role,phone) VALUES (?,?,?,?,?)"
  );

  const adminId = insertUser.run("Admin Head", "admin@college.edu", hash("admin123"), "admin", "9990001").lastInsertRowid;
  const driverId = insertUser.run("Ramesh Kumar", "driver@college.edu", hash("driver123"), "driver", "9990002").lastInsertRowid;
  const parentId = insertUser.run("Suresh Rao", "parent@college.edu", hash("parent123"), "parent", "9990003").lastInsertRowid;
  const studentUserId = insertUser.run("Anita Sharma", "student@college.edu", hash("student123"), "student", "9990004").lastInsertRowid;

  const busId = db.prepare("INSERT INTO buses (bus_number,capacity,driver_id,facilities) VALUES (?,?,?,?)")
    .run("AP-BUS-01", 40, driverId, "AC,WiFi").lastInsertRowid;

  const routeId = db.prepare("INSERT INTO routes (name,bus_id) VALUES (?,?)")
    .run("Route 1 - City Center to College", busId).lastInsertRowid;

  const stop1 = db.prepare("INSERT INTO stops (route_id,name,seq,latitude,longitude,expected_time) VALUES (?,?,?,?,?,?)")
    .run(routeId, "City Center", 1, 16.3067, 80.4365, "07:45").lastInsertRowid;
  db.prepare("INSERT INTO stops (route_id,name,seq,latitude,longitude,expected_time) VALUES (?,?,?,?,?,?)")
    .run(routeId, "Ring Road Junction", 2, 16.3150, 80.4450, "07:55");
  db.prepare("INSERT INTO stops (route_id,name,seq,latitude,longitude,expected_time) VALUES (?,?,?,?,?,?)")
    .run(routeId, "College Gate", 3, 16.3250, 80.4550, "08:10");

  db.prepare("INSERT INTO students (user_id,route_id,stop_id,parent_id,roll_number) VALUES (?,?,?,?,?)")
    .run(studentUserId, routeId, stop1, parentId, "CS2023-045");

  console.log("Seeded database with demo data.");
  console.log("Login credentials -> admin@college.edu/admin123, driver@college.edu/driver123, parent@college.edu/parent123, student@college.edu/student123");
}

export default db;
