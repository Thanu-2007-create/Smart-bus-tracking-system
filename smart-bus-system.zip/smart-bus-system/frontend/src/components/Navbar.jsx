import { useAuth } from "../context/AuthContext";

export default function Navbar() {
  const { user, logout } = useAuth();
  return (
    <div className="navbar">
      <h1>🚌 Smart College Bus System</h1>
      <div className="user-info">
        <span>{user?.name} · {user?.role}</span>
        <button onClick={logout}>Logout</button>
      </div>
    </div>
  );
}
