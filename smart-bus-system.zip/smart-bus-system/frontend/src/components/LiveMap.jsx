import { MapContainer, TileLayer, Marker, Popup, Polyline } from "react-leaflet";
import L from "leaflet";

// Fix default marker icon paths (Leaflet + bundlers quirk)
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png",
  iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
  shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
});

const busIcon = new L.Icon({
  iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
  iconSize: [28, 46],
  iconAnchor: [14, 46],
});

export default function LiveMap({ busPosition, stops = [], center }) {
  const mapCenter = center || busPosition || (stops[0] && [stops[0].latitude, stops[0].longitude]) || [16.3067, 80.4365];
  const polylinePositions = stops
    .filter((s) => s.latitude && s.longitude)
    .map((s) => [s.latitude, s.longitude]);

  return (
    <div className="map-box">
      <MapContainer center={mapCenter} zoom={13} style={{ height: "100%", width: "100%" }}>
        <TileLayer
          attribution='&copy; OpenStreetMap contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        {polylinePositions.length > 1 && (
          <Polyline positions={polylinePositions} color="#1d4ed8" />
        )}
        {stops.map((s) =>
          s.latitude && s.longitude ? (
            <Marker key={s.id} position={[s.latitude, s.longitude]}>
              <Popup>
                {s.name} <br /> Expected: {s.expected_time}
              </Popup>
            </Marker>
          ) : null
        )}
        {busPosition && (
          <Marker position={busPosition} icon={busIcon}>
            <Popup>Bus current location</Popup>
          </Marker>
        )}
      </MapContainer>
    </div>
  );
}
