import { io } from "socket.io-client";

let socket = null;

export function connectSocket() {
  const token = localStorage.getItem("token");
  if (!token) return null;
  if (socket && socket.connected) return socket;

  const BACKEND_URL = import.meta.env.VITE_BACKEND_URL || "http://localhost:5000";
  socket = io(BACKEND_URL, {
    auth: { token },
    transports: ["websocket", "polling"],
  });
  return socket;
}

export function getSocket() {
  return socket;
}

export function disconnectSocket() {
  if (socket) {
    socket.disconnect();
    socket = null;
  }
}
