import { useEffect, useState } from "react";
import Navbar from "../components/Navbar";
import LiveMap from "../components/LiveMap";
import api from "../api";
import { getSocket } from "../socket";
import { useAuth } from "../context/AuthContext";

export default function StudentDashboard() {
  const { user } = useAuth();
  const [student, setStudent] = useState(null);
  const [stops, setStops] = useState([]);
  const [busPosition, setBusPosition] = useState(null);
  const [attendance, setAttendance] = useState([]);
  const [summary, setSummary] = useState({});
  const [alerts, setAlerts] = useState([]);

  useEffect(() => {
    async function load() {
      // In this demo, the seeded student's `students.id` is 1
      const studentsRes = await api.get("/students").catch(() => ({ data: [] }));
      const me = studentsRes.data.find((s) => s.email === user.email) || { id: 1, route_id: 1 };
      setStudent(me);

      if (me.route_id) {
        const stopsRes = await api.get(`/routes/${me.route_id}/stops`);
        setStops(stopsRes.data);
      }

      const attRes = await api.get(`/attendance/student/${me.id}`);
      setAttendance(attRes.data);

      const sumRes = await api.get(`/attendance/student/${me.id}/summary`);
      setSummary(sumRes.data);

      const alertsRes = await api.get("/alerts/mine");
      setAlerts(alertsRes.data);
    }
    load();
  }, [user]);

  useEffect(() => {
    const socket = getSocket();
    if (!socket) return;
    const onLocation = (data) => setBusPosition([data.latitude, data.longitude]);
    const onComeFast = (data) => setAlerts((prev) => [{ type: "come_fast", message: data.message, created_at: new Date().toISOString() }, ...prev]);
    socket.on("bus:location", onLocation);
    socket.on("come_fast_alert", onComeFast);
    return () => {
      socket.off("bus:location", onLocation);
      socket.off("come_fast_alert", onComeFast);
    };
  }, []);

  return (
    <div className="app-shell">
      <Navbar />
      <div className="container">
        <div className="grid grid-3" style={{ marginBottom: 16 }}>
          <div className="card">
            <h3>Bus Info</h3>
            <p>Bus: <b>AP-BUS-01</b></p>
            <p>Route: <b>{student?.route_name || "Route 1"}</b></p>
            <p>Driver: Ramesh Kumar</p>
          </div>
          <div className="card">
            <h3>This Month</h3>
            <p>Present: <b>{summary.present_count || 0}</b></p>
            <p>Late: <b>{summary.late_count || 0}</b></p>
            <p>Absent: <b>{summary.absent_count || 0}</b></p>
          </div>
          <div className="card">
            <h3>Next Trip</h3>
            <p>Morning trip — On time</p>
            <p style={{ fontSize: 13, color: "#6b7280" }}>ETA updates live once driver starts trip</p>
          </div>
        </div>

        <div className="grid grid-2">
          <div className="card">
            <h3>Live Bus Location</h3>
            <LiveMap busPosition={busPosition} stops={stops} />
          </div>

          <div className="card">
            <h3>Alerts & Notifications</h3>
            {alerts.length === 0 && <p style={{ color: "#6b7280" }}>No alerts yet.</p>}
            {alerts.map((a, i) => (
              <div key={i} className={`alert-item ${a.type}`}>
                {a.message}
              </div>
            ))}
          </div>
        </div>

        <div className="card" style={{ marginTop: 16 }}>
          <h3>Recent Attendance</h3>
          <table>
            <thead>
              <tr><th>Date</th><th>Stop</th><th>Status</th></tr>
            </thead>
            <tbody>
              {attendance.map((a) => (
                <tr key={a.id}>
                  <td>{new Date(a.timestamp).toLocaleString()}</td>
                  <td>{a.stop_name}</td>
                  <td><span className={`badge ${a.status}`}>{a.status}</span></td>
                </tr>
              ))}
              {attendance.length === 0 && (
                <tr><td colSpan={3} style={{ color: "#6b7280" }}>No attendance records yet.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
