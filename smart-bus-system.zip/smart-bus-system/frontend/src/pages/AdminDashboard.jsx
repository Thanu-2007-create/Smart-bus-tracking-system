import { useEffect, useState } from "react";
import Navbar from "../components/Navbar";
import LiveMap from "../components/LiveMap";
import api from "../api";
import { getSocket } from "../socket";

export default function AdminDashboard() {
  const [buses, setBuses] = useState([]);
  const [routes, setRoutes] = useState([]);
  const [activeTrips, setActiveTrips] = useState([]);
  const [lateReport, setLateReport] = useState([]);
  const [busPositions, setBusPositions] = useState({}); // bus_id -> [lat,lng]
  const [sosAlerts, setSosAlerts] = useState([]);
  const [newBus, setNewBus] = useState({ bus_number: "", capacity: "", facilities: "" });

  async function loadAll() {
    const [b, r, t, lr] = await Promise.all([
      api.get("/buses"),
      api.get("/routes"),
      api.get("/trips/active"),
      api.get("/attendance/late-report"),
    ]);
    setBuses(b.data);
    setRoutes(r.data);
    setActiveTrips(t.data);
    setLateReport(lr.data);
  }

  useEffect(() => { loadAll(); }, []);

  useEffect(() => {
    const socket = getSocket();
    if (!socket) return;
    const onLocation = (data) =>
      setBusPositions((prev) => ({ ...prev, [data.bus_id]: [data.latitude, data.longitude] }));
    const onSOS = (data) => setSosAlerts((prev) => [data, ...prev]);
    const onTripEnded = () => loadAll();
    socket.on("bus:location", onLocation);
    socket.on("sos_alert", onSOS);
    socket.on("trip:ended", onTripEnded);
    return () => {
      socket.off("bus:location", onLocation);
      socket.off("sos_alert", onSOS);
      socket.off("trip:ended", onTripEnded);
    };
  }, []);

  async function addBus(e) {
    e.preventDefault();
    if (!newBus.bus_number) return;
    await api.post("/buses", newBus);
    setNewBus({ bus_number: "", capacity: "", facilities: "" });
    loadAll();
  }

  async function deleteBus(id) {
    if (!confirm("Delete this bus?")) return;
    await api.delete(`/buses/${id}`);
    loadAll();
  }

  const firstActivePosition = Object.values(busPositions)[0] || null;

  return (
    <div className="app-shell">
      <Navbar />
      <div className="container">
        <div className="grid grid-3" style={{ marginBottom: 16 }}>
          <div className="card"><h3>Total Buses</h3><p style={{ fontSize: 28 }}>{buses.length}</p></div>
          <div className="card"><h3>Active Trips</h3><p style={{ fontSize: 28 }}>{activeTrips.length}</p></div>
          <div className="card"><h3>Late Entries (recent)</h3><p style={{ fontSize: 28 }}>{lateReport.length}</p></div>
        </div>

        {sosAlerts.length > 0 && (
          <div className="card" style={{ marginBottom: 16, borderLeft: "4px solid #dc2626" }}>
            <h3 style={{ color: "#dc2626" }}>🚨 SOS Alerts</h3>
            {sosAlerts.map((a, i) => (
              <div key={i} className="alert-item sos">{a.message}</div>
            ))}
          </div>
        )}

        <div className="grid grid-2" style={{ marginBottom: 16 }}>
          <div className="card">
            <h3>Live Fleet Monitoring</h3>
            <LiveMap busPosition={firstActivePosition} stops={[]} />
            <p style={{ fontSize: 12, color: "#6b7280", marginTop: 8 }}>
              {activeTrips.length} bus(es) currently active. Map centers on the first active bus location.
            </p>
          </div>

          <div className="card">
            <h3>Active Trips</h3>
            <table>
              <thead><tr><th>Bus</th><th>Route</th><th>Type</th><th>Started</th></tr></thead>
              <tbody>
                {activeTrips.map((t) => (
                  <tr key={t.id}>
                    <td>{t.bus_number}</td>
                    <td>{t.route_name}</td>
                    <td>{t.trip_type}</td>
                    <td>{t.start_time ? new Date(t.start_time).toLocaleTimeString() : "-"}</td>
                  </tr>
                ))}
                {activeTrips.length === 0 && <tr><td colSpan={4} style={{ color: "#6b7280" }}>No active trips right now.</td></tr>}
              </tbody>
            </table>
          </div>
        </div>

        <div className="grid grid-2" style={{ marginBottom: 16 }}>
          <div className="card">
            <h3>Fleet & Route Management</h3>
            <form onSubmit={addBus} style={{ display: "flex", gap: 8, marginBottom: 14, flexWrap: "wrap" }}>
              <input
                placeholder="Bus number"
                value={newBus.bus_number}
                onChange={(e) => setNewBus({ ...newBus, bus_number: e.target.value })}
                style={{ padding: 8, borderRadius: 6, border: "1px solid #d1d5db" }}
              />
              <input
                placeholder="Capacity"
                type="number"
                value={newBus.capacity}
                onChange={(e) => setNewBus({ ...newBus, capacity: e.target.value })}
                style={{ padding: 8, borderRadius: 6, border: "1px solid #d1d5db", width: 100 }}
              />
              <input
                placeholder="Facilities"
                value={newBus.facilities}
                onChange={(e) => setNewBus({ ...newBus, facilities: e.target.value })}
                style={{ padding: 8, borderRadius: 6, border: "1px solid #d1d5db" }}
              />
              <button className="btn" type="submit">Add Bus</button>
            </form>
            <table>
              <thead><tr><th>Bus No.</th><th>Capacity</th><th>Driver</th><th></th></tr></thead>
              <tbody>
                {buses.map((b) => (
                  <tr key={b.id}>
                    <td>{b.bus_number}</td>
                    <td>{b.capacity}</td>
                    <td>{b.driver_name || "Unassigned"}</td>
                    <td><button className="btn danger" style={{ padding: "4px 10px", fontSize: 12 }} onClick={() => deleteBus(b.id)}>Delete</button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="card">
            <h3>Routes</h3>
            <table>
              <thead><tr><th>Route</th><th>Bus ID</th></tr></thead>
              <tbody>
                {routes.map((r) => (
                  <tr key={r.id}><td>{r.name}</td><td>{r.bus_id}</td></tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="card">
          <h3>Late Entry Report</h3>
          <table>
            <thead><tr><th>Student</th><th>Route</th><th>Stop</th><th>Timestamp</th></tr></thead>
            <tbody>
              {lateReport.map((l) => (
                <tr key={l.id}>
                  <td>{l.student_name}</td>
                  <td>{l.route_name}</td>
                  <td>{l.stop_name}</td>
                  <td>{new Date(l.timestamp).toLocaleString()}</td>
                </tr>
              ))}
              {lateReport.length === 0 && <tr><td colSpan={4} style={{ color: "#6b7280" }}>No late entries recorded.</td></tr>}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
