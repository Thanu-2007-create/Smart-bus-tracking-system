import { useEffect, useRef, useState } from "react";
import Navbar from "../components/Navbar";
import LiveMap from "../components/LiveMap";
import api from "../api";
import { getSocket } from "../socket";

export default function DriverDashboard() {
  const [buses, setBuses] = useState([]);
  const [routes, setRoutes] = useState([]);
  const [selectedBus, setSelectedBus] = useState("");
  const [selectedRoute, setSelectedRoute] = useState("");
  const [tripType, setTripType] = useState("morning");
  const [activeTrip, setActiveTrip] = useState(null);
  const [stops, setStops] = useState([]);
  const [students, setStudents] = useState([]);
  const [boarded, setBoarded] = useState([]);
  const [sharing, setSharing] = useState(false);
  const [busPosition, setBusPosition] = useState(null);
  const watchId = useRef(null);

  useEffect(() => {
    api.get("/buses").then((r) => setBuses(r.data));
    api.get("/routes").then((r) => setRoutes(r.data));
    api.get("/students").then((r) => setStudents(r.data)).catch(() => setStudents([]));
  }, []);

  useEffect(() => {
    if (selectedRoute) {
      api.get(`/routes/${selectedRoute}/stops`).then((r) => setStops(r.data));
    }
  }, [selectedRoute]);

  async function startTrip() {
    const { data } = await api.post("/trips/start", {
      bus_id: selectedBus,
      route_id: selectedRoute,
      trip_type: tripType,
    });
    setActiveTrip({ id: data.id, bus_id: selectedBus, route_id: selectedRoute });
    setSharing(true);
    beginLocationSharing(data.id);
  }

  function beginLocationSharing(tripId) {
    const socket = getSocket();
    if (!navigator.geolocation) {
      alert("Geolocation not supported by this browser — using simulated movement instead.");
      simulateMovement(tripId, socket);
      return;
    }
    watchId.current = navigator.geolocation.watchPosition(
      (pos) => {
        const { latitude, longitude, speed } = pos.coords;
        setBusPosition([latitude, longitude]);
        socket.emit("driver:location", {
          trip_id: tripId,
          bus_id: selectedBus,
          latitude,
          longitude,
          speed,
        });
      },
      (err) => {
        console.warn("Geolocation error, falling back to simulation:", err.message);
        simulateMovement(tripId, socket);
      },
      { enableHighAccuracy: true, maximumAge: 3000, timeout: 5000 }
    );
  }

  // Fallback for demo/testing when GPS isn't available: moves along seeded stop coordinates
  function simulateMovement(tripId, socket) {
    let i = 0;
    const base = [16.3067, 80.4365];
    watchId.current = setInterval(() => {
      const lat = base[0] + i * 0.0015;
      const lng = base[1] + i * 0.0015;
      setBusPosition([lat, lng]);
      socket.emit("driver:location", { trip_id: tripId, bus_id: selectedBus, latitude: lat, longitude: lng, speed: 25 });
      i += 1;
      if (i > 20) i = 0;
    }, 4000);
  }

  async function endTrip() {
    if (!activeTrip) return;
    await api.post(`/trips/${activeTrip.id}/end`);
    getSocket()?.emit("driver:trip_ended", { trip_id: activeTrip.id });
    if (typeof watchId.current === "number" && navigator.geolocation) {
      navigator.geolocation.clearWatch(watchId.current);
    } else if (watchId.current) {
      clearInterval(watchId.current);
    }
    setSharing(false);
    setActiveTrip(null);
  }

  async function markAttendance(studentId, stopId, method = "manual") {
    if (!activeTrip) return alert("Start a trip first");
    const { data } = await api.post("/attendance/mark", {
      trip_id: activeTrip.id,
      student_id: studentId,
      stop_id: stopId,
      method,
    });
    setBoarded((prev) => [...prev, { studentId, status: data.status, time: new Date() }]);
  }

  async function sendSOS() {
    const [lat, lng] = busPosition || [16.3067, 80.4365];
    await api.post("/alerts/sos", { bus_id: selectedBus, message: "Driver SOS", latitude: lat, longitude: lng });
    alert("SOS sent to admin and parents.");
  }

  return (
    <div className="app-shell">
      <Navbar />
      <div className="container">
        <div className="card" style={{ marginBottom: 16 }}>
          <h3>Trip Management</h3>
          {!activeTrip ? (
            <div className="grid grid-3">
              <div>
                <label>Bus</label>
                <select value={selectedBus} onChange={(e) => setSelectedBus(e.target.value)}>
                  <option value="">Select bus</option>
                  {buses.map((b) => <option key={b.id} value={b.id}>{b.bus_number}</option>)}
                </select>
              </div>
              <div>
                <label>Route</label>
                <select value={selectedRoute} onChange={(e) => setSelectedRoute(e.target.value)}>
                  <option value="">Select route</option>
                  {routes.map((r) => <option key={r.id} value={r.id}>{r.name}</option>)}
                </select>
              </div>
              <div>
                <label>Trip Type</label>
                <select value={tripType} onChange={(e) => setTripType(e.target.value)}>
                  <option value="morning">Morning</option>
                  <option value="evening">Evening</option>
                </select>
              </div>
            </div>
          ) : (
            <p>Trip #{activeTrip.id} is <b>active</b>.</p>
          )}

          <div style={{ marginTop: 12, display: "flex", gap: 10 }}>
            {!activeTrip ? (
              <button className="btn" disabled={!selectedBus || !selectedRoute} onClick={startTrip}>Start Trip</button>
            ) : (
              <button className="btn danger" onClick={endTrip}>End Trip</button>
            )}
            <button className="btn secondary" onClick={sendSOS} disabled={!activeTrip}>🚨 Send SOS</button>
          </div>

          <p style={{ marginTop: 10, fontSize: 13 }}>
            <span className={`status-dot ${sharing ? "on" : "off"}`}></span>
            Location sharing: {sharing ? "ON" : "OFF"}
          </p>
        </div>

        <div className="grid grid-2">
          <div className="card">
            <h3>Live Map</h3>
            <LiveMap busPosition={busPosition} stops={stops} />
          </div>

          <div className="card">
            <h3>Mark Attendance</h3>
            <table>
              <thead><tr><th>Student</th><th>Stop</th><th>Action</th></tr></thead>
              <tbody>
                {students.map((s) => (
                  <tr key={s.id}>
                    <td>{s.name}</td>
                    <td>{s.stop_name}</td>
                    <td>
                      <button className="btn" style={{ padding: "4px 10px", fontSize: 12 }} onClick={() => markAttendance(s.id, s.stop_id)}>
                        Mark Present
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {boarded.length > 0 && (
              <div style={{ marginTop: 12 }}>
                <b>Boarded this trip:</b>
                <ul>
                  {boarded.map((b, i) => <li key={i}>Student #{b.studentId} — <span className={`badge ${b.status}`}>{b.status}</span></li>)}
                </ul>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
