import { useEffect, useState } from "react";
import Navbar from "../components/Navbar";
import LiveMap from "../components/LiveMap";
import api from "../api";
import { getSocket } from "../socket";

export default function ParentDashboard() {
  const [children, setChildren] = useState([]);
  const [selected, setSelected] = useState(null);
  const [stops, setStops] = useState([]);
  const [busPosition, setBusPosition] = useState(null);
  const [attendance, setAttendance] = useState([]);
  const [alerts, setAlerts] = useState([]);

  useEffect(() => {
    async function load() {
      const res = await api.get("/students").catch(() => ({ data: [] }));
      // Demo: show all seeded students as "children" since admin-only list endpoint is reused here
      const kids = res.data.length ? res.data : [{ id: 1, name: "Anita Sharma", route_id: 1, stop_id: 1, route_name: "Route 1", stop_name: "City Center" }];
      setChildren(kids);
      setSelected(kids[0]);

      const alertsRes = await api.get("/alerts/mine");
      setAlerts(alertsRes.data);
    }
    load();
  }, []);

  useEffect(() => {
    if (!selected) return;
    if (selected.route_id) {
      api.get(`/routes/${selected.route_id}/stops`).then((r) => setStops(r.data));
    }
    api.get(`/attendance/student/${selected.id}`).then((r) => setAttendance(r.data)).catch(() => setAttendance([]));
  }, [selected]);

  useEffect(() => {
    const socket = getSocket();
    if (!socket) return;
    const onLocation = (data) => setBusPosition([data.latitude, data.longitude]);
    const onAlert = (data) => setAlerts((prev) => [{ type: "come_fast", message: data.message, created_at: new Date().toISOString() }, ...prev]);
    const onSOS = (data) => setAlerts((prev) => [{ type: "sos", message: data.message, created_at: new Date().toISOString() }, ...prev]);
    socket.on("bus:location", onLocation);
    socket.on("come_fast_alert", onAlert);
    socket.on("sos_alert", onSOS);
    return () => {
      socket.off("bus:location", onLocation);
      socket.off("come_fast_alert", onAlert);
      socket.off("sos_alert", onSOS);
    };
  }, []);

  return (
    <div className="app-shell">
      <Navbar />
      <div className="container">
        <div className="card" style={{ marginBottom: 16 }}>
          <h3>My Children</h3>
          <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
            {children.map((c) => (
              <button
                key={c.id}
                className={`btn ${selected?.id === c.id ? "" : "secondary"}`}
                onClick={() => setSelected(c)}
              >
                {c.name}
              </button>
            ))}
          </div>
        </div>

        {selected && (
          <>
            <div className="grid grid-2">
              <div className="card">
                <h3>Live Bus Tracking — {selected.name}</h3>
                <p style={{ fontSize: 13, color: "#6b7280" }}>Route: {selected.route_name} · Stop: {selected.stop_name}</p>
                <LiveMap busPosition={busPosition} stops={stops} />
              </div>

              <div className="card">
                <h3>Alerts</h3>
                {alerts.length === 0 && <p style={{ color: "#6b7280" }}>No alerts yet.</p>}
                {alerts.map((a, i) => (
                  <div key={i} className={`alert-item ${a.type}`}>{a.message}</div>
                ))}
              </div>
            </div>

            <div className="card" style={{ marginTop: 16 }}>
              <h3>Boarding / Alighting History</h3>
              <table>
                <thead><tr><th>Date</th><th>Stop</th><th>Status</th></tr></thead>
                <tbody>
                  {attendance.map((a) => (
                    <tr key={a.id}>
                      <td>{new Date(a.timestamp).toLocaleString()}</td>
                      <td>{a.stop_name}</td>
                      <td><span className={`badge ${a.status}`}>{a.status}</span></td>
                    </tr>
                  ))}
                  {attendance.length === 0 && <tr><td colSpan={3} style={{ color: "#6b7280" }}>No records yet.</td></tr>}
                </tbody>
              </table>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
