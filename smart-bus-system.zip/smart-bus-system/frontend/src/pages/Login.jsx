import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

const DEMO_ACCOUNTS = [
  { role: "admin", email: "admin@college.edu", password: "admin123" },
  { role: "driver", email: "driver@college.edu", password: "driver123" },
  { role: "parent", email: "parent@college.edu", password: "parent123" },
  { role: "student", email: "student@college.edu", password: "student123" },
];

export default function Login() {
  const [email, setEmail] = useState("student@college.edu");
  const [password, setPassword] = useState("student123");
  const [error, setError] = useState("");
  const { login } = useAuth();
  const navigate = useNavigate();

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");
    try {
      const user = await login(email, password);
      navigate(`/${user.role}`);
    } catch (err) {
      setError(err?.response?.data?.error || "Login failed");
    }
  }

  return (
    <div className="login-wrap">
      <form className="login-card" onSubmit={handleSubmit}>
        <h2>🚌 Smart Bus Login</h2>
        <label>Email</label>
        <input value={email} onChange={(e) => setEmail(e.target.value)} type="email" required />
        <label>Password</label>
        <input value={password} onChange={(e) => setPassword(e.target.value)} type="password" required />
        {error && <p style={{ color: "red", fontSize: 13 }}>{error}</p>}
        <button className="btn" style={{ width: "100%" }} type="submit">Login</button>

        <div style={{ marginTop: 18, fontSize: 12, color: "#6b7280" }}>
          <p>Demo accounts (click to autofill):</p>
          {DEMO_ACCOUNTS.map((acc) => (
            <div
              key={acc.role}
              style={{ cursor: "pointer", padding: "4px 0" }}
              onClick={() => {
                setEmail(acc.email);
                setPassword(acc.password);
              }}
            >
              <b>{acc.role}</b>: {acc.email} / {acc.password}
            </div>
          ))}
        </div>
      </form>
    </div>
  );
}
